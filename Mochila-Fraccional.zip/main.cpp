#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>

using namespace std;

struct Objeto {
    char id;
    double valor;
    double peso;

    double densidad() const {
        return valor / peso;
    }
};

bool comparar(const Objeto& a, const Objeto& b) {
    return a.densidad() > b.densidad();
}

void mochilaFraccional(double capacidad, vector<Objeto>& objetos) {
    sort(objetos.begin(), objetos.end(), comparar);

    double valorTotal = 0.0;
    cout << "Objetos seleccionados:\n";

    for (const auto& obj : objetos) {
        if (capacidad <= 0) break;

        if (obj.peso <= capacidad) {
            capacidad -= obj.peso;
            valorTotal += obj.valor;
            cout << obj.id << " completo\n";
        } else {
            double fraccion = capacidad / obj.peso;
            valorTotal += obj.valor * fraccion;
            cout << capacidad << "/" << obj.peso << " Parte del objeto " << obj.id << "\n";
            capacidad = 0;
        }
    }

    cout << "Valor total aproximado: " << valorTotal << "\n\n";
}

int main() {
    cout << "Ejemplo 1\n";
    vector<Objeto> ej1 = {{'A', 60, 10}, {'B', 100, 20}, {'C', 120, 30}};
    mochilaFraccional(50, ej1);

    cout << "Ejemplo 2\n";
    vector<Objeto> ej2 = {{'A', 80, 20}, {'B', 100, 10}, {'C', 120, 30}};
    mochilaFraccional(25, ej2);

    return 0;
}