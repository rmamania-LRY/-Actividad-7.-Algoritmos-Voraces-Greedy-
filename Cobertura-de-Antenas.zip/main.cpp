#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

void coberturaAntenas(vector<int> casas, int R) {
    sort(casas.begin(), casas.end());

    vector<int> antenas;
    size_t i = 0;
    size_t n = casas.size();

    while (i < n) {
        int posAntena = casas[i] + R;
        antenas.push_back(posAntena);

        int limiteDerecho = posAntena + R;
        while (i < n && casas[i] <= limiteDerecho) {
            i++;
        }
    }

    cout << "Antenas colocadas aproximadamente en:\n";
    for (int pos : antenas) {
        cout << pos << "\n";
    }
    cout << "Cantidad total: " << antenas.size() << "\n\n";
}

int main() {
    cout << "Ejemplo 1\n";
    vector<int> ej1 = {1, 2, 7, 11, 20, 21, 30};
    coberturaAntenas(ej1, 5);

    cout << "Ejemplo 2\n";
    vector<int> ej2 = {2, 4, 8, 15, 18, 22};
    coberturaAntenas(ej2, 3);

    return 0;
}